<?php

namespace App\Filament\Resources\VerifikasiPengeluaranResource\Pages;

use App\Filament\Resources\VerifikasiPengeluaranResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateVerifikasiPengeluaran extends CreateRecord
{
    protected static string $resource = VerifikasiPengeluaranResource::class;
}

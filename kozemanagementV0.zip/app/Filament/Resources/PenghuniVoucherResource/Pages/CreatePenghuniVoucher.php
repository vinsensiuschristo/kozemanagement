<?php

namespace App\Filament\Resources\PenghuniVoucherResource\Pages;

use App\Filament\Resources\PenghuniVoucherResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePenghuniVoucher extends CreateRecord
{
    protected static string $resource = PenghuniVoucherResource::class;
}

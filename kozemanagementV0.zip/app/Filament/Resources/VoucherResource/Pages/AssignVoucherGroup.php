<?php

namespace App\Filament\Resources\VoucherResource\Pages;

use App\Filament\Resources\VoucherResource;
use Filament\Forms\Form;
use Illuminate\Support\Facades\DB;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\Page;

class AssignVoucherGroup extends Page implements HasForms
{
    use InteractsWithForms;
    protected static string $resource = VoucherResource::class;

    protected static string $view = 'filament.resources.voucher-resource.pages.assign-voucher-group';
    protected static ?string $title = 'Assign Voucher to Penghun';

    public function mount(): void
    {
        $this->fill([
            'voucher_id' => null,
            'penghuni_ids' => [],
        ]);
    }
    public ?array $data = [];

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('voucher_id')
                ->label('Voucher')
                ->options(Vouccher::pluck('nama_voucher', 'id'))
                ->required()
                ->searchable(),

            Forms\Components\Repeater::make('penghuni_ids')
                ->label('Pilih Penghuni')
                ->multiple()
                ->options(Penghuni::pluck('nama', 'id'))
                ->searchable()
                ->required(),
        ])->statePath('data');
    }

    public function assign(): void
    {
        foreach ($this->data['penghuni_ids'] as $penghuniId) {
            PenghuniVoucher::create([
                'id' => Str::uuid(),
                'penghuni_id' => $penghuniId,
                'voucher_id' => $this->data['voucher_id'],
                'periode' => now()->toDateString(),
                'is_used' => false,
            ]);
        }

        Notification::make()
            ->success()
            ->title('Voucher berhasil diberikan ke penghuni.')
            ->send();

        $this->fillForm(); // reset form
    }
}
